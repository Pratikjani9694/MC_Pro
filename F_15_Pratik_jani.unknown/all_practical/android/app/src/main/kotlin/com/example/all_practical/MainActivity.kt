package com.example.all_practical

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
